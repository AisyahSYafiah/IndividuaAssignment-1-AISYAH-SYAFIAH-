package com.profile.dao;

import com.profile.model.ProfileBean;
import com.profile.util.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProfileDAO {
    
    // Insert profile - Derby uses IDENTITY for auto-increment
    public boolean insertProfile(ProfileBean profile) {
        // Note: In Derby, use GENERATED ALWAYS AS IDENTITY for auto-increment
        String sql = "INSERT INTO profile (name, student_id, program, email, hobbies, introduction) VALUES (?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, profile.getName());
            pstmt.setString(2, profile.getStudentId());
            pstmt.setString(3, profile.getProgram());
            pstmt.setString(4, profile.getEmail());
            pstmt.setString(5, profile.getHobbies());
            pstmt.setString(6, profile.getIntroduction());
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            System.err.println("Error inserting profile: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // Get all profiles
    public List<ProfileBean> getAllProfiles() {
        List<ProfileBean> profiles = new ArrayList<>();
        String sql = "SELECT * FROM profile ORDER BY id DESC";
        
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                ProfileBean profile = extractProfileFromResultSet(rs);
                profiles.add(profile);
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting profiles: " + e.getMessage());
            e.printStackTrace();
        }
        return profiles;
    }
    
    // Search profiles
    public List<ProfileBean> searchProfiles(String keyword) {
        List<ProfileBean> profiles = new ArrayList<>();
        String sql = "SELECT * FROM profile WHERE name LIKE ? OR student_id LIKE ? OR program LIKE ? ORDER BY name";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            String searchPattern = "%" + keyword + "%";
            pstmt.setString(1, searchPattern);
            pstmt.setString(2, searchPattern);
            pstmt.setString(3, searchPattern);
            
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                ProfileBean profile = extractProfileFromResultSet(rs);
                profiles.add(profile);
            }
            
        } catch (SQLException e) {
            System.err.println("Error searching profiles: " + e.getMessage());
            e.printStackTrace();
        }
        return profiles;
    }
    
    // Helper method to extract profile from ResultSet
    private ProfileBean extractProfileFromResultSet(ResultSet rs) throws SQLException {
        ProfileBean profile = new ProfileBean();
        profile.setId(rs.getInt("id"));
        profile.setName(rs.getString("name"));
        profile.setStudentId(rs.getString("student_id"));
        profile.setProgram(rs.getString("program"));
        profile.setEmail(rs.getString("email"));
        profile.setHobbies(rs.getString("hobbies"));
        profile.setIntroduction(rs.getString("introduction"));
        return profile;
    }
    
    // Delete profile
    public boolean deleteProfile(int id) {
        String sql = "DELETE FROM profile WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting profile: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // Get profile by ID
    public ProfileBean getProfileById(int id) {
        String sql = "SELECT * FROM profile WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return extractProfileFromResultSet(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error getting profile by ID: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }
    
    // Update profile
    public boolean updateProfile(ProfileBean profile) {
        String sql = "UPDATE profile SET name = ?, student_id = ?, program = ?, email = ?, hobbies = ?, introduction = ? WHERE id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, profile.getName());
            pstmt.setString(2, profile.getStudentId());
            pstmt.setString(3, profile.getProgram());
            pstmt.setString(4, profile.getEmail());
            pstmt.setString(5, profile.getHobbies());
            pstmt.setString(6, profile.getIntroduction());
            pstmt.setInt(7, profile.getId());
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            System.err.println("Error updating profile: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // Filter profiles by programme
    public List<ProfileBean> filterByProgramme(String programme) {
        List<ProfileBean> profiles = new ArrayList<>();
        String sql = "SELECT * FROM profile WHERE program = ? ORDER BY name";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, programme);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                ProfileBean profile = extractProfileFromResultSet(rs);
                profiles.add(profile);
            }
            
        } catch (SQLException e) {
            System.err.println("Error filtering by programme: " + e.getMessage());
            e.printStackTrace();
        }
        return profiles;
    }
    
    // Filter profiles by hobby
    public List<ProfileBean> filterByHobby(String hobby) {
        List<ProfileBean> profiles = new ArrayList<>();
        String sql = "SELECT * FROM profile WHERE hobbies LIKE ? ORDER BY name";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            String hobbyPattern = "%" + hobby + "%";
            pstmt.setString(1, hobbyPattern);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                ProfileBean profile = extractProfileFromResultSet(rs);
                profiles.add(profile);
            }
            
        } catch (SQLException e) {
            System.err.println("Error filtering by hobby: " + e.getMessage());
            e.printStackTrace();
        }
        return profiles;
    }
}