package com.profile.controller;

import com.profile.model.ProfileBean;
import com.profile.dao.ProfileDAO;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ProfileServlet")
public class ProfileServlet extends HttpServlet {
    private ProfileDAO profileDAO;
    
    @Override
    public void init() throws ServletException {
        profileDAO = new ProfileDAO();
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String action = request.getParameter("action");
        
        if ("update".equals(action)) {
            // Handle profile update
            String idStr = request.getParameter("id");
            if (idStr == null || idStr.isEmpty()) {
                response.sendRedirect("error.jsp");
                return;
            }
            
            int id = Integer.parseInt(idStr);
            String name = request.getParameter("name");
            String studentId = request.getParameter("studentId");
            String program = request.getParameter("program");
            String email = request.getParameter("email");
            String hobbies = request.getParameter("hobbies");
            String introduction = request.getParameter("introduction");
            
            ProfileBean profile = new ProfileBean(name, studentId, program, email, hobbies, introduction);
            profile.setId(id);
            
            boolean isSuccess = profileDAO.updateProfile(profile);
            
            if (isSuccess) {
                response.sendRedirect("ProfileServlet");
            } else {
                response.sendRedirect("error.jsp");
            }
        } else {
            // Handle profile creation
            String name = request.getParameter("name");
            String studentId = request.getParameter("studentId");
            String program = request.getParameter("program");
            String email = request.getParameter("email");
            String hobbies = request.getParameter("hobbies");
            String introduction = request.getParameter("introduction");
            
            // Create ProfileBean object
            ProfileBean profile = new ProfileBean(name, studentId, program, email, hobbies, introduction);
            
            // Insert into database
            boolean isSuccess = profileDAO.insertProfile(profile);
            
            if (isSuccess) {
                // Set profile as request attribute
                request.setAttribute("profile", profile);
                // Forward to profile.jsp
                request.getRequestDispatcher("profile.jsp").forward(request, response);
            } else {
                response.sendRedirect("error.jsp");
            }
        }
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String action = request.getParameter("action");
        
        if ("delete".equals(action)) {
            // Handle delete
            String idStr = request.getParameter("id");
            if (idStr != null && !idStr.isEmpty()) {
                try {
                    int id = Integer.parseInt(idStr);
                    profileDAO.deleteProfile(id);
                } catch (NumberFormatException e) {
                    System.err.println("Invalid ID format: " + idStr);
                }
            }
            response.sendRedirect("ProfileServlet");
        } else if ("edit".equals(action)) {
            // Handle edit - show edit form
            String idStr = request.getParameter("id");
            if (idStr != null && !idStr.isEmpty()) {
                try {
                    int id = Integer.parseInt(idStr);
                    ProfileBean profile = profileDAO.getProfileById(id);
                    if (profile != null) {
                        request.setAttribute("profile", profile);
                        request.getRequestDispatcher("editProfile.jsp").forward(request, response);
                        return;
                    }
                } catch (NumberFormatException e) {
                    System.err.println("Invalid ID format: " + idStr);
                }
            }
            response.sendRedirect("ProfileServlet");
        } else if ("filterProgramme".equals(action)) {
            // Handle filter by programme
            String programme = request.getParameter("programme");
            if (programme != null && !programme.isEmpty()) {
                request.setAttribute("profiles", profileDAO.filterByProgramme(programme));
                request.setAttribute("selectedProgramme", programme);
            } else {
                request.setAttribute("profiles", profileDAO.getAllProfiles());
            }
            request.getRequestDispatcher("viewProfiles.jsp").forward(request, response);
        } else if ("filterHobby".equals(action)) {
            // Handle filter by hobby
            String hobby = request.getParameter("hobby");
            if (hobby != null && !hobby.isEmpty()) {
                request.setAttribute("profiles", profileDAO.filterByHobby(hobby));
                request.setAttribute("selectedHobby", hobby);
            } else {
                request.setAttribute("profiles", profileDAO.getAllProfiles());
            }
            request.getRequestDispatcher("viewProfiles.jsp").forward(request, response);
        } else if ("search".equals(action)) {
            // Handle search
            String keyword = request.getParameter("keyword");
            request.setAttribute("profiles", profileDAO.searchProfiles(keyword));
            request.getRequestDispatcher("viewProfiles.jsp").forward(request, response);
        } else {
            // View all profiles
            request.setAttribute("profiles", profileDAO.getAllProfiles());
            request.getRequestDispatcher("viewProfiles.jsp").forward(request, response);
        }
    }
}