package com.profile.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class DBConnection {
    
    public static Connection getConnection() {
        try {
            // This ALWAYS works
            String url = "jdbc:derby:myProfileDB;create=true";
            
            // Load driver
            Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
            
            // Get connection
            Connection conn = DriverManager.getConnection(url);
            
            // Create table
            Statement stmt = conn.createStatement();
            String sql = "CREATE TABLE profile (" +
                        "id INT PRIMARY KEY GENERATED ALWAYS AS IDENTITY," +
                        "name VARCHAR(100)," +
                        "student_id VARCHAR(20)," +
                        "program VARCHAR(100)," +
                        "email VARCHAR(100)," +
                        "hobbies VARCHAR(500)," +
                        "introduction VARCHAR(2000)" +
                        ")";
            
            try {
                stmt.execute(sql);
                System.out.println("Table created.");
            } catch (Exception e) {
                // Table already exists - ignore
            }
            
            stmt.close();
            return conn;
            
        } catch (Exception e) {
            System.out.println("DB Error: " + e.toString());
            return null;
        }
    }
    
    public static void testConnection() {
        try {
            Connection conn = getConnection();
            if (conn != null) {
                System.out.println("SUCCESS! Database ready.");
                conn.close();
            }
        } catch (Exception e) {
            System.out.println("Test failed: " + e.getMessage());
        }
    }
    
    public static void main(String[] args) throws Exception {
        testConnection();
    }
}